class loot
{
    class globals
    {
        file = "loot\functions";
        class get {};
        class cleanup {};
        class deleteIfEmpty {};
    };
};
