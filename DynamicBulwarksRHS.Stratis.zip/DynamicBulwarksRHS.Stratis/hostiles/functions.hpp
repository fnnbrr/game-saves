class CreateHostiles
{
    class globals
    {
        file = "hostiles\functions";
        class suiExplode{};
    };
};
