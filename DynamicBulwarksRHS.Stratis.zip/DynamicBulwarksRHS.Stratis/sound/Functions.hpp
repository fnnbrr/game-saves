class sound
{
    class globals
    {
        file = "sound\functions";
        class say3DGlobal {};
    };
};
