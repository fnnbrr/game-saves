# DynamicBulwarks

Attempting to get a version of DynamicBulwarks working entirely off content from the excellent Unsung Vietnam mod.
Planning to just modify the Cold War version of this scenario to instead filter for Unsung content.
