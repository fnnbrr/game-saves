class bulwark
{
    class bulwarkBox
    {
        file = "bulwark\functions";
        class bulwarkLocation {};
        class findPlaceAround {};
        class probeBox {};
        class purchaseGui {};
        class roomCentre {};
        class roomVolume {};
        class startWave {};
    		class endWave {};
        class revivePlayer{};
    };
};
