class area
{
    class globals
    {
        file = "area\functions";
        class createBlur {};
		class enforcement {};
    };
};
