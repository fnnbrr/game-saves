class supports
{
    class globals
    {
        file = "supports\functions";
        class supplyDrop {};
        class paraTroop {};
        class reconUAV {};
        class airStrike {};
        class ragePack {};
        class armaKart {};
        class mindConGas {};
        class droneControl {};
        class mineField {};
        class telePlode{};
    };
};
