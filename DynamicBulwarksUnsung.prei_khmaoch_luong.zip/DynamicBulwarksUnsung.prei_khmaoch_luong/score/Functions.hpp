class killPoints
{
    class globals
    {
        file = "score\functions";
        class init {postInit = 1;};
        class add {};
        class spend {};
        class hit {};
        class killed {};
        class updateHud {};
        class support {};
    };
};
